insert into users (username, password, enabled)
	values('naveen', '1234', true);
	
	
insert into authorities(username, authority)
	values('naveen', 'ROLE_ADMIN');
	